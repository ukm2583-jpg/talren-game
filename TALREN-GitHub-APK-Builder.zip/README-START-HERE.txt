TALREN — Android APK builder (GitHub Actions)

This ZIP contains Android source code, NOT a finished APK.

1. Create a free GitHub repository named talren-game (public is easiest).
2. Upload the CONTENTS of this folder to the repository, preserving folders including .github/workflows/build-apk.yml. The files must be at the repository root, not nested under TALREN-GitHub-APK-Builder.
   Tip: Extract the ZIP first. On a phone, GitHub's web uploader may make folder uploads awkward; github.dev (press . on a repository page) or a Git-capable Android app can help preserve paths.
3. Open the repository's Actions tab, select Build TALREN APK, choose Run workflow. A push to main also starts a build automatically.
4. When the run succeeds, open it and download artifact TALREN-Android-APK (a ZIP containing app-debug.apk).
5. Extract app-debug.apk and send it to your friend on WhatsApp as a DOCUMENT.
6. Your friend taps the APK and approves installation from that source if Android asks.

This is a debug-signed APK for personal testing; do not publish it as a production release. GitHub Actions needs an internet connection to download Android build tools. Fonts loaded from Google Fonts may fall back when offline.

No APK has been compiled or device-tested in this environment.
