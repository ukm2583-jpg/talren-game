package com.talren.game;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle state) { super.onCreate(state);
 getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
 web = new WebView(this); web.setBackgroundColor(0xff07050f); setContentView(web);
 WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
 web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient());
 web.loadUrl("file:///android_asset/index.html"); }
 @Override protected void onDestroy(){ if(web!=null)web.destroy(); super.onDestroy(); }
}
