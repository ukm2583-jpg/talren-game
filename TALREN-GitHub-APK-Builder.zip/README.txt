TALREN Android APK build

1. Open this folder in Android Studio (recent version with JDK 17).
2. Let Gradle sync and download Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find app-debug.apk in app/build/outputs/apk/debug/.
5. Share the APK file with your Samsung friend via WhatsApp as a document.
6. Android may require allowing installs from WhatsApp or the file manager.

This embeds the existing TALREN V11 HTML game. Google Fonts may fall back offline.
No APK was built or tested in this environment.
